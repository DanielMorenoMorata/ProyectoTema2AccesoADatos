/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import controlador.Controlador;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import vista.Ventana_Conexion;

/**
 *
 * @author Daniel_Moreno_Morata
 */
public class VistaSeleccion extends javax.swing.JFrame {

    private static Connection conexion;
    public static DefaultTableModel model;


    public static Connection conexion() {
        String server = Ventana_Conexion.con.get(0);
        String port = Ventana_Conexion.con.get(1);
        String user = Ventana_Conexion.con.get(2);
        String pass = Ventana_Conexion.con.get(3);

        return Controlador.comprobarConexion(server, port, user, pass);

    }

    public VistaSeleccion() {
        initComponents();
        Ventana_Conexion in = new Ventana_Conexion(this, true);

        in.setVisible(true);
        
        añadirTabla();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Table_Selector = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Colum_Selector = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Operator_Selector = new javax.swing.JComboBox<>();
        TextValor = new javax.swing.JTextField();
        TextSelect = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        TableContent = new javax.swing.JTable();
        TextRun = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        TextDate2 = new javax.swing.JFormattedTextField();
        LabelFecha1 = new javax.swing.JLabel();
        LabelFecha2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        Table_Selector.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Table_SelectorItemStateChanged(evt);
            }
        });
        Table_Selector.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Table_SelectorActionPerformed(evt);
            }
        });

        jLabel1.setText("Tablas");

        jLabel2.setText("Columnas");

        Colum_Selector.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Colum_SelectorItemStateChanged(evt);
            }
        });
        Colum_Selector.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Colum_SelectorActionPerformed(evt);
            }
        });
        Colum_Selector.addVetoableChangeListener(new java.beans.VetoableChangeListener() {
            public void vetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {
                Colum_SelectorVetoableChange(evt);
            }
        });

        jLabel3.setText("Operador");

        jLabel4.setText("Valor");

        Operator_Selector.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " " }));
        Operator_Selector.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Operator_SelectorActionPerformed(evt);
            }
        });

        TextValor.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                TextValorFocusLost(evt);
            }
        });
        TextValor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextValorActionPerformed(evt);
            }
        });

        TextSelect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextSelectActionPerformed(evt);
            }
        });

        TableContent.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        TableContent.getTableHeader().setReorderingAllowed(false);
        TableContent.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
                TableContentInputMethodTextChanged(evt);
            }
        });
        jScrollPane1.setViewportView(TableContent);

        TextRun.setText("Ejecutar");
        TextRun.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextRunActionPerformed(evt);
            }
        });

        jLabel5.setText("Pinche en el recuadro de abajo, una vez seleccionado los 4 campos, para que se genere la sentencia");

        TextDate2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                TextDate2FocusLost(evt);
            }
        });
        TextDate2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TextDate2ActionPerformed(evt);
            }
        });

        LabelFecha1.setText("Primera fecha Between");

        LabelFecha2.setText("Segunda fecha Between");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(122, 122, 122)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Colum_Selector, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(Operator_Selector, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(40, 40, 40)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(TextValor, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(LabelFecha1))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(TextDate2, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(LabelFecha2))
                        .addGap(53, 53, 53))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(TextSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                        .addComponent(TextRun)
                        .addGap(22, 22, 22))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(Table_Selector, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 584, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 533, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel1)
                .addGap(30, 30, 30)
                .addComponent(Table_Selector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LabelFecha1, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(LabelFecha2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Colum_Selector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Operator_Selector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextValor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextDate2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextSelect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TextRun))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(255, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Operator_SelectorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Operator_SelectorActionPerformed

    }//GEN-LAST:event_Operator_SelectorActionPerformed

    private void Table_SelectorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Table_SelectorActionPerformed

    }//GEN-LAST:event_Table_SelectorActionPerformed

    private void Table_SelectorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Table_SelectorItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_Table_SelectorItemStateChanged

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try {
            conexion.close();

        } catch (SQLException ex) {
            Logger.getLogger(VistaSeleccion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowClosing

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
    }//GEN-LAST:event_formWindowActivated

    private void Colum_SelectorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Colum_SelectorItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_Colum_SelectorItemStateChanged

    private void TextSelectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextSelectActionPerformed

    }//GEN-LAST:event_TextSelectActionPerformed

    private void TextValorFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TextValorFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_TextValorFocusLost

    private void TextRunActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextRunActionPerformed

    }//GEN-LAST:event_TextRunActionPerformed

    private void Colum_SelectorVetoableChange(java.beans.PropertyChangeEvent evt)throws java.beans.PropertyVetoException {//GEN-FIRST:event_Colum_SelectorVetoableChange
        // TODO add your handling code here:
    }//GEN-LAST:event_Colum_SelectorVetoableChange

    private void TextDate2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_TextDate2FocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_TextDate2FocusLost

    private void TextValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextValorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextValorActionPerformed

    private void TableContentInputMethodTextChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_TableContentInputMethodTextChanged
 
    }//GEN-LAST:event_TableContentInputMethodTextChanged

    private void Colum_SelectorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Colum_SelectorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Colum_SelectorActionPerformed

    private void TextDate2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TextDate2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TextDate2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VistaSeleccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VistaSeleccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VistaSeleccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VistaSeleccion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new VistaSeleccion().setVisible(true);
            }
        });
    }



    public void añadirTabla(){
     try {

            conexion = conexion();
            DefaultComboBoxModel comboBox = new DefaultComboBoxModel();
            DatabaseMetaData metaDatos = conexion.getMetaData();
            String[] parametro = {"TABLE"};

            ResultSet rs = metaDatos.getTables(null, null, "%", parametro);

            while (rs.next()) {
                comboBox.addElement(rs.getString(3));

                Table_Selector.setModel(comboBox);

            }
        } catch (SQLException ex) {
            Logger.getLogger(VistaSeleccion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    



 

    
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Colum_Selector;
    private javax.swing.JLabel LabelFecha1;
    private javax.swing.JLabel LabelFecha2;
    private javax.swing.JComboBox<String> Operator_Selector;
    private javax.swing.JTable TableContent;
    private javax.swing.JComboBox<String> Table_Selector;
    private javax.swing.JFormattedTextField TextDate2;
    private javax.swing.JButton TextRun;
    private javax.swing.JTextField TextSelect;
    private javax.swing.JTextField TextValor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
