package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Daniel_Moreno_Morata
 */
public class Controlador {

    private static Connection conexion;

    public static Connection comprobarConexion(String server, String port, String user, String pass) {

        try {
            conexion = 
                    DriverManager.getConnection("jdbc:oracle:thin:@" + server + ":" + port + ":" + "xe", user, pass);
            return conexion;
        } 
        
        catch (SQLException ex) {

        }
        return null;
    }

}
